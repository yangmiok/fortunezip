# Fortune Fullstack (Flask + Postgres + Redis + Nginx)

## Quick start

```bash
docker-compose up -d --build
```

> 如果你使用的是 Docker Compose v2，也可以用：
> 
> ```bash
> docker compose up -d --build
> ```

### Env (可选)

本项目 **不需要** 额外创建 `.env` 也能启动（`docker-compose.yml` 已内置默认值）。

如果你想自定义数据库/密钥参数：

```bash
cp .env.example .env
```

- Frontend (Nginx): http://localhost:8080
- API: http://localhost:8080/api/health  (through nginx reverse proxy)
- Postgres: localhost:5432
- Redis: localhost:6379

## Troubleshooting

如果“注册失败”，请先确认 API 正常：

- 打开：`http://localhost:8080/api/health` 应返回 `{ "ok": true }`
- 查看日志：

```bash
docker-compose logs -f api
docker-compose logs -f db
```

## Accounts

- 用户：在注册页注册即可
- 管理员：
  - 账号：admin
  - 密码：admin
  - 后台入口：登录页底部“管理员登录”，或直接访问 `/admin_login.html`
