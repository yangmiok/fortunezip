#!/bin/sh
set -e

echo "[entrypoint] waiting for postgres..."
python - <<'PY'
import os, time
from urllib.parse import urlparse

import psycopg2

url = os.environ.get("DATABASE_URL")
if not url:
    raise SystemExit("DATABASE_URL is not set")

u = urlparse(url)
dbname = (u.path or "/")[1:] or "postgres"
host = u.hostname or "db"
port = u.port or 5432
user = u.username or "postgres"
password = u.password or ""

deadline = time.time() + 60
last_err = None
while time.time() < deadline:
    try:
        conn = psycopg2.connect(
            dbname=dbname,
            host=host,
            port=port,
            user=user,
            password=password,
            connect_timeout=3,
        )
        conn.close()
        print("[entrypoint] postgres is ready")
        break
    except Exception as e:
        last_err = e
        time.sleep(1)
else:
    raise SystemExit(f"postgres not ready: {last_err}")
PY

echo "[entrypoint] initializing database..."
python -c "from app import init_db; init_db()"

echo "[entrypoint] starting gunicorn..."
exec gunicorn -b 0.0.0.0:5000 wsgi:app --workers 2 --threads 4 --timeout 60
