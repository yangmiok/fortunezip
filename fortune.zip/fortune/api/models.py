import datetime as dt

from sqlalchemy import String, DateTime, Integer, BigInteger, ForeignKey, Boolean, Text
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column


class Base(DeclarativeBase):
    pass


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    username: Mapped[str] = mapped_column(String(64), unique=True, index=True, nullable=False)
    password_hash: Mapped[str] = mapped_column(String(255), nullable=False)
    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=False), default=dt.datetime.utcnow, nullable=False)


class Admin(Base):
    __tablename__ = "admins"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    username: Mapped[str] = mapped_column(String(64), unique=True, index=True, nullable=False)
    password_hash: Mapped[str] = mapped_column(String(255), nullable=False)
    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=False), default=dt.datetime.utcnow, nullable=False)


class UserSubmission(Base):
    """One row per user form submission (a.k.a. a reading request).

    We keep frequently queried fields as structured columns, and store the full
    payload in JSONB for future schema evolution.
    """

    __tablename__ = "user_submissions"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    user_id: Mapped[int | None] = mapped_column(Integer, ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True)

    service_type: Mapped[str] = mapped_column(String(32), nullable=False, index=True)  # bazi/ziwei/liuyao/...

    name: Mapped[str | None] = mapped_column(String(64), nullable=True)

    # Common extracted fields
    gender: Mapped[str | None] = mapped_column(String(8), nullable=True)  # 男/女
    calendar: Mapped[str | None] = mapped_column(String(16), nullable=True)  # 公历/农历
    leap: Mapped[str | None] = mapped_column(String(8), nullable=True)  # 是/否

    year: Mapped[int | None] = mapped_column(Integer, nullable=True)
    month: Mapped[int | None] = mapped_column(Integer, nullable=True)
    day: Mapped[int | None] = mapped_column(Integer, nullable=True)
    hour: Mapped[str | None] = mapped_column(String(16), nullable=True)  # 子/丑/.../不详

    province: Mapped[str | None] = mapped_column(String(64), nullable=True)
    city: Mapped[str | None] = mapped_column(String(64), nullable=True)

    payload_json: Mapped[dict] = mapped_column(JSONB, nullable=False, default=dict)

    # Queue + expedite (manual acceleration)
    queue_status: Mapped[str] = mapped_column(String(16), nullable=False, default="waiting", index=True)
    priority: Mapped[int] = mapped_column(Integer, nullable=False, default=0, index=True)  # 0 normal, 10 expedited

    expedite_requested: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False, index=True)
    expedite_status: Mapped[str] = mapped_column(String(16), nullable=False, default="none", index=True)
    expedite_note: Mapped[str | None] = mapped_column(Text, nullable=True)
    expedited_at: Mapped[dt.datetime | None] = mapped_column(DateTime(timezone=False), nullable=True)
    processed_at: Mapped[dt.datetime | None] = mapped_column(DateTime(timezone=False), nullable=True)

    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=False), default=dt.datetime.utcnow, nullable=False, index=True)


