(function () {
  const tokenKey = 'fd_token';
  const token = localStorage.getItem(tokenKey);
  const path = (location.pathname || '').toLowerCase();

  // Pages that do NOT require user login
  const publicPages = ['login.html', 'register.html', 'admin_login.html'];
  const isPublic = publicPages.some(p => path.endsWith('/' + p) || path.endsWith(p));

  if (!token && !isPublic) {
    // Preserve intended destination
    const dest = location.pathname + location.search + location.hash;
    const url = '/login.html?next=' + encodeURIComponent(dest);
    location.replace(url);
  }
})();
