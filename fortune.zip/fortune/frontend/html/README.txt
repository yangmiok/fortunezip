Fortune Demo（前端静态演示）
================================

打开方式：
- 直接双击 index.html（或用任意静态服务器打开）

页面流转：
1) index.html  提交表单
2) result.html 查看测算结果 + 人生K线缩略图入口
3) kline.html  0-100岁年度K线详情（点击某年进入月度）
4) months.html 月度K线 + 本月重点领域条形评分

说明：
- 数据为前端随机生成，用于演示交互与页面连贯性
- 参数通过 URL QueryString 透传（type/year/month/day/hour/province/city/gender 等）
