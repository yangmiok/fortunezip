import os
import datetime as dt
from typing import Optional, Dict, Any

import jwt
import redis
from flask import Flask, request, jsonify
from flask_cors import CORS
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker
from werkzeug.security import generate_password_hash, check_password_hash

from models import Base, User, Admin, UserSubmission


def env(name: str, default: Optional[str] = None) -> str:
    v = os.getenv(name, default)
    if v is None:
        raise RuntimeError(f"Missing env var: {name}")
    return v


JWT_SECRET = env("JWT_SECRET", "change-me")
JWT_ISSUER = env("JWT_ISSUER", "fortune-demo")
JWT_EXPIRES_MIN = int(env("JWT_EXPIRES_MIN", "43200"))  # 30 days
DATABASE_URL = env("DATABASE_URL")
REDIS_URL = env("REDIS_URL", "redis://redis:6379/0")

engine = create_engine(DATABASE_URL, pool_pre_ping=True, future=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)

rds = redis.Redis.from_url(REDIS_URL, decode_responses=True)

app = Flask(__name__)
CORS(app, resources={r"/api/*": {"origins": "*"}})


def init_db() -> None:
    # Create tables if missing
    Base.metadata.create_all(engine)

    # Lightweight "migration" for existing volumes: add new columns when they don't exist.
    # This keeps the project runnable without Alembic.
    with engine.begin() as conn:
        # Add queue/expedite columns to user_submissions
        conn.execute(text("""
        DO $$
        BEGIN
          IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='user_submissions' AND column_name='name') THEN
            ALTER TABLE user_submissions ADD COLUMN name VARCHAR(64);
          END IF;
          IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='user_submissions' AND column_name='queue_status') THEN
            ALTER TABLE user_submissions ADD COLUMN queue_status VARCHAR(16) NOT NULL DEFAULT 'waiting';
          END IF;
          IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='user_submissions' AND column_name='priority') THEN
            ALTER TABLE user_submissions ADD COLUMN priority INT NOT NULL DEFAULT 0;
          END IF;
          IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='user_submissions' AND column_name='expedite_requested') THEN
            ALTER TABLE user_submissions ADD COLUMN expedite_requested BOOLEAN NOT NULL DEFAULT FALSE;
          END IF;
          IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='user_submissions' AND column_name='expedite_status') THEN
            ALTER TABLE user_submissions ADD COLUMN expedite_status VARCHAR(16) NOT NULL DEFAULT 'none';
          END IF;
          IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='user_submissions' AND column_name='expedite_note') THEN
            ALTER TABLE user_submissions ADD COLUMN expedite_note TEXT;
          END IF;
          IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='user_submissions' AND column_name='expedited_at') THEN
            ALTER TABLE user_submissions ADD COLUMN expedited_at TIMESTAMP;
          END IF;
          IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='user_submissions' AND column_name='processed_at') THEN
            ALTER TABLE user_submissions ADD COLUMN processed_at TIMESTAMP;
          END IF;
        END $$;
        """))

        # Best-effort indexes (ignore if already exist)
        conn.execute(text("CREATE INDEX IF NOT EXISTS idx_user_submissions_queue ON user_submissions (queue_status, priority, created_at);"))
        conn.execute(text("CREATE INDEX IF NOT EXISTS idx_user_submissions_expedite ON user_submissions (expedite_status, expedite_requested);"))
    # Ensure admin exists
    with SessionLocal() as db:
        admin = db.query(Admin).filter(Admin.username == "admin").one_or_none()
        if admin is None:
            db.add(Admin(username="admin", password_hash=generate_password_hash("admin")))
            db.commit()


def make_token(subject: str, kind: str) -> str:
    now = dt.datetime.utcnow()
    payload = {
        "iss": JWT_ISSUER,
        "sub": subject,
        "kind": kind,
        "iat": int(now.timestamp()),
        "exp": int((now + dt.timedelta(minutes=JWT_EXPIRES_MIN)).timestamp()),
    }
    return jwt.encode(payload, JWT_SECRET, algorithm="HS256")


def decode_token(token: str) -> Dict[str, Any]:
    return jwt.decode(token, JWT_SECRET, algorithms=["HS256"], issuer=JWT_ISSUER)


def bearer_token() -> Optional[str]:
    h = request.headers.get("Authorization", "")
    if h.startswith("Bearer "):
        return h[len("Bearer "):].strip()
    return None


def require_token(kind: str) -> Dict[str, Any]:
    token = bearer_token()
    if not token:
        raise PermissionError("未登录")
    payload = decode_token(token)
    if payload.get("kind") != kind:
        raise PermissionError("无权限")
    return payload


@app.get("/api/health")
def health():
    return jsonify({"ok": True})


@app.post("/api/auth/register")
def register():
    data = request.get_json(silent=True) or {}
    username = (data.get("username") or "").strip()
    password = (data.get("password") or "").strip()

    if not username or not password:
        return jsonify({"message": "请输入账号和密码"}), 400
    if len(password) < 4:
        return jsonify({"message": "密码至少4位"}), 400

    with SessionLocal() as db:
        exists = db.query(User).filter(User.username == username).one_or_none()
        if exists:
            return jsonify({"message": "该账号已存在"}), 409

        u = User(username=username, password_hash=generate_password_hash(password))
        db.add(u)
        db.commit()
        db.refresh(u)

        token = make_token(subject=username, kind="user")
        return jsonify({"username": username, "token": token})


@app.post("/api/auth/login")
def login():
    data = request.get_json(silent=True) or {}
    username = (data.get("username") or "").strip()
    password = (data.get("password") or "").strip()

    if not username or not password:
        return jsonify({"message": "请输入账号和密码"}), 400

    with SessionLocal() as db:
        u = db.query(User).filter(User.username == username).one_or_none()
        if (u is None) or (not check_password_hash(u.password_hash, password)):
            return jsonify({"message": "账号或密码不正确"}), 401

        token = make_token(subject=username, kind="user")
        return jsonify({"username": username, "token": token})


@app.post("/api/admin/login")
def admin_login():
    data = request.get_json(silent=True) or {}
    username = (data.get("username") or "").strip()
    password = (data.get("password") or "").strip()

    if not username or not password:
        return jsonify({"message": "请输入账号和密码"}), 400

    with SessionLocal() as db:
        a = db.query(Admin).filter(Admin.username == username).one_or_none()
        if (a is None) or (not check_password_hash(a.password_hash, password)):
            return jsonify({"message": "账号或密码不正确"}), 401

        token = make_token(subject=username, kind="admin")
        return jsonify({"username": username, "token": token})


@app.get("/api/admin/users")
def admin_users():
    try:
        _ = require_token("admin")
    except Exception as e:
        msg = str(e) or "未登录"
        return jsonify({"message": msg}), 401

    with SessionLocal() as db:
        rows = db.query(User).order_by(User.id.asc()).all()
        return jsonify({
            "users": [
                {"id": u.id, "username": u.username, "created_at": u.created_at.isoformat() if u.created_at else None}
                for u in rows
            ]
        })


@app.post("/api/submissions")
def create_submission():
    """Persist a user's form submission.

    Frontend sends the full form payload plus 'service_type'.
    We extract common fields for admin listing.
    """
    try:
        payload = require_token("user")
    except Exception as e:
        msg = str(e) or "未登录"
        return jsonify({"message": msg}), 401

    data = request.get_json(silent=True) or {}
    service_type = (data.get("service_type") or "").strip() or (data.get("type") or "").strip()
    if not service_type:
        return jsonify({"message": "缺少测算类型"}), 400

    username = payload.get("sub")

    def to_int(v: Any) -> Optional[int]:
        try:
            return int(v)
        except Exception:
            return None

    # 构建要检查的关键字段
    name = data.get("name") or data.get("fullname") or data.get("nickname") or None
    gender = data.get("gender") or None
    calendar = data.get("calendar") or None
    leap = data.get("leap") or None
    year = to_int(data.get("year"))
    month = to_int(data.get("month"))
    day = to_int(data.get("day"))
    hour = data.get("hour") or None
    
    # 检查是否已存在相同的提交
    with SessionLocal() as db:
        # 获取当前用户ID
        user_id = None
        u = db.query(User).filter(User.username == username).one_or_none()
        if u is not None:
            user_id = u.id
        
        # 检查是否存在相同内容且状态不是已取消/已完成的提交
        existing = db.query(UserSubmission).filter(
            UserSubmission.service_type == service_type,
            UserSubmission.name == name,
            UserSubmission.gender == gender,
            UserSubmission.calendar == calendar,
            UserSubmission.leap == leap,
            UserSubmission.year == year,
            UserSubmission.month == month,
            UserSubmission.day == day,
            UserSubmission.hour == hour,
            UserSubmission.user_id == user_id
        ).filter(
            # 排除已取消或已完成的提交（如果需要）
            # UserSubmission.queue_status.notin_(["cancelled", "completed"])
            # 如果要检查所有状态，包括已完成和已取消的，可以去掉这个filter
        ).first()
        
        if existing:
            # 如果已存在相同提交，返回现有记录的ID
            return jsonify({
                "id": existing.id,
                "message": "您已提交过相同的内容",
                "duplicate": True
            }), 200
        
        # 创建新记录
        rec = UserSubmission(
            service_type=service_type,
            name=name,
            gender=gender,
            calendar=calendar,
            leap=leap,
            year=year,
            month=month,
            day=day,
            hour=hour,
            province=(data.get("province") or None),
            city=(data.get("city") or None),
            payload_json=data,
            queue_status="waiting",
            priority=0,
            expedite_requested=False,
            expedite_status="none",
            user_id=user_id  # 直接设置user_id
        )
        
        db.add(rec)
        db.commit()
        db.refresh(rec)
        return jsonify({"id": rec.id, "duplicate": False}), 201


@app.get("/api/my/submissions")
def my_submissions():
    """List the current user's submissions (for 'My Records' page)."""
    try:
        payload = require_token("user")
    except Exception as e:
        msg = str(e) or "未登录"
        return jsonify({"message": msg}), 401

    username = payload.get("sub")

    service_type = (request.args.get("service_type") or "").strip()
    days_raw = (request.args.get("days") or "").strip()
    page = max(int(request.args.get("page", 1)), 1)
    page_size = min(max(int(request.args.get("page_size", 20)), 1), 100)

    days: Optional[int] = None
    if days_raw:
        try:
            days = int(days_raw)
        except Exception:
            days = None

    with SessionLocal() as db:
        u = db.query(User).filter(User.username == username).one_or_none()
        if u is None:
            return jsonify({"page": page, "page_size": page_size, "total": 0, "items": []})

        q = db.query(UserSubmission).filter(UserSubmission.user_id == u.id)
        if service_type:
            q = q.filter(UserSubmission.service_type == service_type)
        if days and days > 0:
            since = dt.datetime.utcnow() - dt.timedelta(days=days)
            q = q.filter(UserSubmission.created_at >= since)

        total = q.count()
        rows = (
            q.order_by(UserSubmission.created_at.desc())
             .offset((page - 1) * page_size)
             .limit(page_size)
             .all()
        )

        items = []
        for s in rows:
            items.append({
                "id": s.id,
                "service_type": s.service_type,
                "name": getattr(s, "name", None),
                "gender": s.gender,
                "calendar": getattr(s, "calendar", None),
                "leap": getattr(s, "leap", None),
                "year": s.year,
                "month": s.month,
                "day": s.day,
                "hour": s.hour,
                "province": s.province,
                "city": s.city,
                "queue_status": getattr(s, "queue_status", None),
                "priority": getattr(s, "priority", 0),
                "expedite_status": getattr(s, "expedite_status", None),
                "created_at": s.created_at.isoformat() if s.created_at else None,
            })

        return jsonify({"page": page, "page_size": page_size, "total": total, "items": items})


@app.get("/api/my/submissions/<int:sid>")
def my_submission_detail(sid: int):
    """Get full payload for a single submission, owner-only."""
    try:
        payload = require_token("user")
    except Exception as e:
        msg = str(e) or "未登录"
        return jsonify({"message": msg}), 401

    username = payload.get("sub")

    with SessionLocal() as db:
        u = db.query(User).filter(User.username == username).one_or_none()
        if u is None:
            return jsonify({"message": "用户不存在"}), 404

        s = db.query(UserSubmission).filter(UserSubmission.id == sid, UserSubmission.user_id == u.id).one_or_none()
        if s is None:
            return jsonify({"message": "记录不存在"}), 404

        return jsonify({
            "id": s.id,
            "service_type": s.service_type,
            "name": getattr(s, "name", None),
            "gender": s.gender,
            "calendar": getattr(s, "calendar", None),
            "leap": getattr(s, "leap", None),
            "year": s.year,
            "month": s.month,
            "day": s.day,
            "hour": s.hour,
            "province": s.province,
            "city": s.city,
            "queue_status": getattr(s, "queue_status", None),
            "priority": getattr(s, "priority", 0),
            "expedite_requested": getattr(s, "expedite_requested", False),
            "expedite_status": getattr(s, "expedite_status", None),
            "expedite_note": getattr(s, "expedite_note", None),
            "created_at": s.created_at.isoformat() if s.created_at else None,
            "payload_json": s.payload_json or {},
        })


@app.get("/api/admin/submissions")
def admin_submissions():
    try:
        _ = require_token("admin")
    except Exception as e:
        msg = str(e) or "未登录"
        return jsonify({"message": msg}), 401

    service_type = (request.args.get("service_type") or "").strip()
    expedite = (request.args.get("expedite") or "").strip()  # requested/approved/none...
    page = max(int(request.args.get("page", 1)), 1)
    page_size = min(max(int(request.args.get("page_size", 20)), 1), 100)

    with SessionLocal() as db:
        q = db.query(UserSubmission, User.username).outerjoin(User, User.id == UserSubmission.user_id)
        if service_type:
            q = q.filter(UserSubmission.service_type == service_type)
        if expedite:
            # convenience filtering for客服/管理员
            if expedite == "requested":
                q = q.filter(UserSubmission.expedite_status == "requested")
            else:
                q = q.filter(UserSubmission.expedite_status == expedite)

        total = q.count()
        rows = (
            q.order_by(UserSubmission.created_at.desc(), UserSubmission.id.desc())
             .offset((page - 1) * page_size)
             .limit(page_size)
             .all()
        )

        items = []
        for s, uname in rows:
            items.append({
                "id": s.id,
                "username": uname,
                "service_type": s.service_type,
                "name": getattr(s, "name", None),
                "gender": s.gender,
                "calendar": s.calendar,
                "leap": s.leap,
                "year": s.year,
                "month": s.month,
                "day": s.day,
                "hour": s.hour,
                "province": s.province,
                "city": s.city,
                "queue_status": getattr(s, "queue_status", None),
                "priority": getattr(s, "priority", 0),
                "expedite_requested": getattr(s, "expedite_requested", False),
                "expedite_status": getattr(s, "expedite_status", None),
                "created_at": s.created_at.isoformat() if s.created_at else None,
                "payload_json": s.payload_json,
            })

        return jsonify({"page": page, "page_size": page_size, "total": total, "items": items})


def _compute_queue_position(db, sid: int) -> tuple[int, int]:
    """Return (position, ahead) in the active queue."""
    me = db.query(UserSubmission).filter(UserSubmission.id == sid).one_or_none()
    if me is None:
        return (0, 0)
    if me.queue_status not in ("waiting", "running"):
        return (1, 0)

    # Count how many active submissions should be processed before this one.
    ahead = db.execute(text(
        """
        SELECT COUNT(1) AS cnt
        FROM user_submissions
        WHERE queue_status IN ('waiting','running')
          AND (
               priority > :p
            OR (priority = :p AND created_at < :ca)
            OR (priority = :p AND created_at = :ca AND id < :id)
          )
        """),
        {"p": int(me.priority or 0), "ca": me.created_at, "id": me.id}
    ).scalar_one()
    pos = int(ahead) + 1
    return (pos, int(ahead))


@app.get("/api/queue/status")
def queue_status():
    """Queue status for a submission (owner-only)."""
    try:
        payload = require_token("user")
    except Exception as e:
        return jsonify({"message": str(e) or "未登录"}), 401

    sid_raw = (request.args.get("sid") or "").strip()
    try:
        sid = int(sid_raw)
    except Exception:
        return jsonify({"message": "参数错误"}), 400

    username = payload.get("sub")

    with SessionLocal() as db:
        u = db.query(User).filter(User.username == username).one_or_none()
        if u is None:
            return jsonify({"message": "用户不存在"}), 404
        s = db.query(UserSubmission).filter(UserSubmission.id == sid, UserSubmission.user_id == u.id).one_or_none()
        if s is None:
            return jsonify({"message": "记录不存在"}), 404

        pos, ahead = _compute_queue_position(db, sid)

        # "Product" simulation: auto-advance status based on position/time.
        now = dt.datetime.utcnow()
        created = s.created_at or now
        elapsed = (now - created).total_seconds()
        # expedited requests are faster in UI
        target = 15 if (s.priority or 0) >= 10 else 60

        if s.queue_status == "waiting" and pos == 1:
            s.queue_status = "running"
            db.commit()
        if s.queue_status in ("waiting", "running") and pos == 1 and elapsed >= target:
            s.queue_status = "success"
            s.processed_at = now
            db.commit()

        # Very rough ETA
        avg = 12 if (s.priority or 0) >= 10 else 45
        eta = max(0, ahead * avg)

        return jsonify({
            "id": s.id,
            "queue_status": s.queue_status,
            "priority": int(s.priority or 0),
            "position": pos,
            "ahead": ahead,
            "estimated_seconds": int(eta),
            "expedite_requested": bool(getattr(s, "expedite_requested", False)),
            "expedite_status": getattr(s, "expedite_status", "none"),
        })


@app.post("/api/queue/expedite_request")
def queue_expedite_request():
    """User marks that they want to contact CS for manual acceleration."""
    try:
        payload = require_token("user")
    except Exception as e:
        return jsonify({"message": str(e) or "未登录"}), 401

    data = request.get_json(silent=True) or {}
    sid = data.get("sid")
    try:
        sid = int(sid)
    except Exception:
        return jsonify({"message": "参数错误"}), 400

    note = (data.get("note") or "").strip() or None
    channel = (data.get("channel") or "").strip() or None

    username = payload.get("sub")
    with SessionLocal() as db:
        u = db.query(User).filter(User.username == username).one_or_none()
        if u is None:
            return jsonify({"message": "用户不存在"}), 404
        s = db.query(UserSubmission).filter(UserSubmission.id == sid, UserSubmission.user_id == u.id).one_or_none()
        if s is None:
            return jsonify({"message": "记录不存在"}), 404

        s.expedite_requested = True
        s.expedite_status = "requested"
        if channel:
            s.expedite_note = (f"渠道:{channel}\n" + (note or "")).strip() or None
        elif note:
            s.expedite_note = note
        db.commit()
        return jsonify({"ok": True})


@app.post("/api/admin/submissions/<int:sid>/expedite")
def admin_expedite(sid: int):
    try:
        _ = require_token("admin")
    except Exception as e:
        return jsonify({"message": str(e) or "未登录"}), 401

    with SessionLocal() as db:
        s = db.query(UserSubmission).filter(UserSubmission.id == sid).one_or_none()
        if s is None:
            return jsonify({"message": "记录不存在"}), 404
        s.priority = 10
        s.expedite_status = "approved"
        s.expedited_at = dt.datetime.utcnow()
        db.commit()
        return jsonify({"ok": True})


@app.post("/api/admin/submissions/<int:sid>/expedite_cancel")
def admin_expedite_cancel(sid: int):
    try:
        _ = require_token("admin")
    except Exception as e:
        return jsonify({"message": str(e) or "未登录"}), 401

    with SessionLocal() as db:
        s = db.query(UserSubmission).filter(UserSubmission.id == sid).one_or_none()
        if s is None:
            return jsonify({"message": "记录不存在"}), 404
        s.priority = 0
        s.expedite_requested = False
        s.expedite_status = "cancelled"
        db.commit()
        return jsonify({"ok": True})


# Example redis usage: store a simple counter (not required by UI)
@app.post("/api/debug/hit")
def debug_hit():
    n = rds.incr("fortune:hit")
    return jsonify({"hit": n})


if __name__ == "__main__":
    init_db()
    app.run(host="0.0.0.0", port=5000)

# Route for submitting user data
@app.route('/submit_form', methods=['POST'])
def submit_form():
    data = request.json  # Assume form data is sent as JSON
    user_id = data.get('user_id')
    service_type = data.get('service_type')
    name = data.get('name')
    gender = data.get('gender')
    calendar = data.get('calendar')

    # Insert into UserSubmission table
    new_submission = UserSubmission(
        user_id=user_id,
        service_type=service_type,
        name=name,
        gender=gender,
        calendar=calendar,
    )

    db_session = SessionLocal()
    db_session.add(new_submission)
    db_session.commit()

    return jsonify({"message": "Data submitted successfully!"})

# Route for querying user data based on ID
@app.route('/get_submission/<int:submission_id>', methods=['GET'])
def get_submission(submission_id):
    db_session = SessionLocal()
    submission = db_session.query(UserSubmission).filter(UserSubmission.id == submission_id).first()

    if not submission:
        return jsonify({"message": "Submission not found"}), 404

    return jsonify({
        "id": submission.id,
        "user_id": submission.user_id,
        "service_type": submission.service_type,
        "name": submission.name,
        "gender": submission.gender,
        "calendar": submission.calendar,
    })

import requests

# New route to query external data
@app.route('/query_external_data', methods=['POST'])
def query_external_data():
    data = request.json
    user_id = data.get('user_id')
    service_type = data.get('service_type')
    submission_id = data.get('submission_id')

    # Simulate calling an external API
    external_data = query_external_api(user_id, service_type)

    # Save the external data to fortune_result_details table
    result_entry = FortuneResultDetails(
        user_submission_id=submission_id,
        result_data=external_data
    )

    db_session = SessionLocal()
    db_session.add(result_entry)
    db_session.commit()

    return jsonify({"message": "External data saved successfully!"})

# Function to simulate querying an external API
def query_external_api(user_id, service_type):
    url = "http://external.api/endpoint"  # Placeholder URL for the external API
    params = {"user_id": user_id, "service_type": service_type}
    response = requests.post(url, json=params)
    return response.json()
